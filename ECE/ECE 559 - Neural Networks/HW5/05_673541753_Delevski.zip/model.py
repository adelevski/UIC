import keras
from keras import layers
import numpy as np
import random
import io
from keras.models import Sequential
from keras.layers import Dense, Dropout, LSTM
from keras.utils import np_utils
from keras.callbacks import ModelCheckpoint
from matplotlib import pyplot as plt
import tensorflow as tf

########## PARAMETERS ###############

seq_length = 11
EON = '~'

#####################################

with io.open("new_names.txt", "r") as f:
    text = f.read().lower()
text = text.replace("\n", "")
print("Total length:", len(text))

chars = sorted(list(set(text)))
chars = chars[-1:] + chars[:-1]
print("Total chars:", len(chars))
char_indices = dict((c, i) for i, c in enumerate(chars))
indices_char = dict((i, c) for i, c in enumerate(chars))

maxlen = seq_length
names = []
for i in range(0, len(text), maxlen):
    names.append(text[i : i + maxlen])
print("Number of sequences:", len(names))

x = np.zeros((len(names), maxlen, len(chars)), dtype=np.int)
y = np.zeros((len(names), maxlen, len(chars)), dtype=np.int)
eon = np.zeros((len(chars)))
eon[0] = 1
for i, name in enumerate(names):
    for t, char in enumerate(name):
        x[i, t, char_indices[char]] = 1
    y[i][:-1] = x[i][1:]
    y[i][-1] = eon

model = Sequential()
model.add(LSTM(128, input_shape=(maxlen, len(chars)), return_sequences=True))
model.add(Dense(len(chars), activation='softmax'))
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

filepath = "model.hdf5"
checkpoint = ModelCheckpoint(filepath, monitor='loss', verbose=1, save_best_only=True, mode='min')
desired_callbacks = [checkpoint]

# for i in range(epochs):
history = model.fit(x, y, epochs=100, validation_split=0.15, batch_size=128, callbacks=desired_callbacks)

model.save('my_model.hdf5')

# list all data in history
print(history.history.keys())
# summarize history for accuracy
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()
# summarize history for loss
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()
