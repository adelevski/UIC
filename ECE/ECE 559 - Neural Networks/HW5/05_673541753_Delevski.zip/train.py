import keras
from keras import layers
import numpy as np
import random
import io
from keras.models import Sequential
from keras.layers import Dense, Dropout, LSTM
from keras.utils import np_utils
from keras.callbacks import ModelCheckpoint
from matplotlib import pyplot as plt
import tensorflow as tf

########## PARAMETERS ###############

seq_length = 11
EON = '~'

#####################################

########## PRE-PROCESSING ##############

with open('names.txt', 'r') as names:
    lines = [line.rstrip('\n') for line in names]
    new_names = open("new_names.txt", "w")
    for line in lines:
        new_line = line.lower()
        while len(new_line) < seq_length:
            new_line += EON
        new_names.write(f"{new_line}\n")
names.close()
new_names.close()

##########################################

with io.open("new_names.txt", "r") as f:
    text = f.read().lower()
text = text.replace("\n", "")
print("Total length:", len(text))

chars = sorted(list(set(text)))
chars = chars[-1:] + chars[:-1]
print("Total chars:", len(chars))
char_indices = dict((c, i) for i, c in enumerate(chars))
indices_char = dict((i, c) for i, c in enumerate(chars))

maxlen = seq_length
names = []
for i in range(0, len(text), maxlen):
    names.append(text[i : i + maxlen])
print("Number of sequences:", len(names))

x = np.zeros((len(names), maxlen, len(chars)), dtype=np.int)
y = np.zeros((len(names), maxlen, len(chars)), dtype=np.int)
eon = np.zeros((len(chars)))
eon[0] = 1
for i, name in enumerate(names):
    for t, char in enumerate(name):
        x[i, t, char_indices[char]] = 1
    y[i][:-1] = x[i][1:]
    y[i][-1] = eon

f.close()
