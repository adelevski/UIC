import keras
from keras import layers
import numpy as np
import random
import io
from keras.models import Sequential
from keras.layers import Dense, Dropout, LSTM
from keras.utils import np_utils
from keras.callbacks import ModelCheckpoint
from matplotlib import pyplot as plt
import tensorflow as tf

########## PARAMETERS ###############

seq_length = 11
EON = '~'
input_letter = 'b'      ##  <-------------- THIS IS WHERE YOU CHOOSE WHAT LETTER TO INPUT

#####################################

with io.open("new_names.txt", "r") as f:
    text = f.read().lower()
text = text.replace("\n", "")

chars = sorted(list(set(text)))
chars = chars[-1:] + chars[:-1]
char_indices = dict((c, i) for i, c in enumerate(chars))
indices_char = dict((i, c) for i, c in enumerate(chars))

maxlen = seq_length
names = []
for i in range(0, len(text), maxlen):
    names.append(text[i : i + maxlen])

model = tf.keras.models.load_model('my_model.hdf5')

names_list = []
while len(names_list) < 20:
    sequence = input_letter
    x_pred = np.zeros((1, maxlen, len(chars)))
    for i in range(maxlen):
        for t, char in enumerate(sequence):
            x_pred[0, t, char_indices[char]] = 1.0
        preds = model.predict(x_pred, verbose=0)
        indices = np.argsort(-1*preds[0][i])[:3]
        if 0 in indices:
            sequence += EON
        else:
            sequence += indices_char[random.choice(indices)]
    if sequence not in names_list:
        names_list.append(sequence)

for name in names_list:
    for char in name:
        if char == '~':
            index = name.index(char)
            neat = name[:index]
    print(neat.title())
